TicTacToe
=========

This is a TicTacToe game built with JavaScript and jQuery for instructional purposes. The file app.js has directions that the students can follow to make the game work.
