 // $.getJSON("assets/blob.json", function(data) {
 //    $("#content-template").html(tmpl({objects:data}));
 // });

//  $(document).ready("#pop", function() {
// 	$(this).animateCSS("shake", {delay: 5000})
// })

//  $( window ).load(function() {
//   // Run code
// });

//   $(document).on("click", "#pop", function() {
// 	$(this).animateCSS("shake")
// })

//   $(document).ready(function() {
//     // Stuff here
// });





  $(document).ready( function(){
  $('#pop1').animateCSS("fadeIn");
  $('#pop2').animateCSS("fadeIn", {delay: 250});
  $('#pop3').animateCSS("fadeIn", {delay: 500});
  $('#pop4').animateCSS("fadeIn", {delay: 750});
  $('#pop5').animateCSS("fadeIn", {delay: 1000});
  $('#pop6').animateCSS("fadeIn", {delay: 1250});
  $('#pop7').animateCSS("fadeIn", {delay: 1500});
  $('#pop8').animateCSS("fadeIn", {delay: 1750});
  $('#pop9').animateCSS("fadeIn", {delay: 2000});
  $('#pop').animateCSS("fadeIn", {delay: 2500});

});