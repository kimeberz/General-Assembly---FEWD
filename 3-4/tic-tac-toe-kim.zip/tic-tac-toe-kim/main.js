$(document).on("click", "td", function() {
	alert("click worked!");
});